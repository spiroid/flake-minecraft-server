PATCH NOTES

Release v1.10.0

	-Updated Curios
	-Added Artifacts
	-Added Modular Backpacks
	-Added Relics
	-Added YYZs Backpack

	-Changed version label (v[MainVersion].[ContentNumber].[MinorFixes])

Release v1.0.8

	-Changed hunger to coffee beans in Appleskin, Farmers Delight, LevelZ, Sophisticated Core and Travelers Backpack
	-Changed Pack Icon
	-Added Chipped
	-Added Crafting Tweaks
	-Added Trash Cans

Release v1.0.7

	-Remade buttons to match Coffee GUI v2.1.0
	-A lot of minor things that I forgot to write down

	-Added Runes
	-Added Immersive Aircraft
	-Added Immersive Furniture
	-Added Immersive Melodies
	-Added Immersive Paintings

Release v1.0.6

	-Added Create
	-Added Farmers Delight
	-Added Quark
	-Added Quark Oddities
	-Added Supplementaries
	-Added Waystones
	-Added Let's Do Mods:
		-Let's Do Bakery - Farm&Charm Compat
		-Let's Do Beachparty
		-Let's Do Candlelight - Farm&Charm Compat
		-Let's Do Farm & Charm
		-Let's Do HerbalBrews
		-Let's Do Meadow
		-Let's Do NetherVinery
		-Let's Do Vinery

Release v1.0.5

	-Added textures for Accesorify (Doesn't work but textures are there)
	-Added Easy Shulker Boxes
	-Added Inventory Management
	-Added Inventory Sort
	-Added Inventory Sorter
	-Added Lightweight Inventory Sorting
	-Added Nemo's Inventory Sorting
	-Added Sort It Out
	-Added Spell Engine
	-Added Terrastorage
	-Added Utility Belt

Release v1.0.4

	-Added Accessories (and Owo-lib)
	-Added Corpse
	-Added Easy Anvil
	-Added Easy Magic
	-Added Easy Shulker Boxes (For some reason it doesn't work)
	-Added Polymorph
	-Added Trashslot

	-Added Resource Backpack's (By Motherose)
	-Added Trade Cycling (Original texture by Motherose, remade by me)

Release v1.0.3

	-Added JobsAddon
	-Added LevelZ
	-Added LibZ
	-Added PartyAddon
	-Added Simple Radio
	-Added Simple Voice Chat
	-Added Storage Drawers
	-Added Tom's Simple Storage

	-Updated Cursors Extended

Release v1.0.2

	-Added Backpacked
	-Added Inmis
	-Added Sophisticated Core (works for both Sophisticated Backpacks and Sophisticated Storage)
	-Added Traveler's Backpack

Release v1.0.1

	-Added EMI
	-Added JEI
	-Added REI

Release v1.0.0

	-Added AppleSkin
	-Added Curios
	-Added Cursors Extended
	-Added Item Swapper
	-Added Mod Menu
	-Added Trinkets

Do not distribute or republish anywhere else without permission, the only page that offers this resourcepack is Modrinth and Planet Minecraft, and only by me. If you see any version of this resourcepack anywhere else, do not download, it was uploaded without my supervision and could be dangerous.

Modrinth: https://modrinth.com/resourcepack/modded-coffee-gui
Curseforge: https://www.curseforge.com/minecraft/texture-packs/modded-coffee-gui
Planet Minecraft: https://www.planetminecraft.com/texture-pack/dark-coffe-gui/
Ko-Fi (if you want 👉👈): https://ko-fi.com/restlesspip