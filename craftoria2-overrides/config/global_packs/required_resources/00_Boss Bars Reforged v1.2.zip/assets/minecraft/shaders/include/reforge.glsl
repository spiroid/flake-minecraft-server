//#moj_import <fog.glsl>
//#moj_import <dynamictransforms.glsl>
//#moj_import <globals.glsl>
//#moj_import <projection.glsl>
//======================================================================================================================================
struct Data 
{
   vec3 position;
   vec2 uv0;
   vec4 color;
};


vec2[] corners = vec2[](vec2(0, 0), vec2(0, 1), vec2(1, 1), vec2(1, 0));
float margin = 0;

Data null = Data(vec3(0),vec2(0),vec4(0));


Data Reforge(/*mat4 ProjMat,*/ /* float GameTime,*/ sampler2D Sampler0, vec3 Position, vec2 texCoord0,vec4 Color) {
    
    //== Setup

    vec3 pos = Position;

    vec4 textColor = Color;

    int vertID = gl_VertexID % 4;
    vec2 corner = corners[vertID];
    vec4 color = round(texture(Sampler0, texCoord0-(0.001*corner))*255);

    //== Shader

    if(color.a == 1 && Color != vec4(1)) return null;


    return Data(pos,texCoord0,textColor);
}
